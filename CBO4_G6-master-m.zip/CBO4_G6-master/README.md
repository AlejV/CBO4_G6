# CBO4_G6
The repository of Group 6, class CB04. The program can be launched using the .exe file. The test plan is included in this branch. 
